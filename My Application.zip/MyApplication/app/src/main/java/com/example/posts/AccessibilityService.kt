package com.example.posts

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast


class AccessibilityService : AccessibilityService() {
    private lateinit var handler: Handler
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            if (!packageName.isNullOrEmpty()) {
                val pm: PackageManager = packageManager
                try {
                    val appInfo: ApplicationInfo = pm.getApplicationInfo(packageName, 0)
                    val appName: CharSequence = pm.getApplicationLabel(appInfo)
                    Log.d("AppName", "$appName - $packageName")
                } catch (e: PackageManager.NameNotFoundException) {
                    if (e.message.equals("com.com.whatsapp")){
                        //show toast
                        //
                        val handler = Handler(Looper.getMainLooper())

                        handler.post {
                            Toast.makeText(baseContext, "", Toast.LENGTH_LONG).show()
                        }

                    }
                    Log.d("AppNameex", e.message.toString())

                }
            }
        }
    }


    override fun onInterrupt() {

    }
    override fun onServiceConnected() {
        handler = Handler(mainLooper)

        val info = AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                AccessibilityEvent.TYPE_VIEW_FOCUSED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        info.notificationTimeout = 100
        this.serviceInfo = info
        Log.d("on service Connected","service connected")
    }
}
